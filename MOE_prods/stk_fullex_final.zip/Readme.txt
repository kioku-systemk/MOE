!=======================================================!
|                                                       |
|             S  y  s  t  e  m    K                     |
|                                                       |
|                     full Ex !                         |
|                                                       |
|                a   demo  in   64KB                    |
!=======================================================!
From Kyoto, Japan

party released at 26/8/2005
final released at 19/11/2005

System requirements :
- P4-2Ghz or AthlonXP1800+ over
- any video cards with OpenGLv1.3 support
  (Radeon9000, GeForceFx5200 over)
- 128MB of RAM
- any sound card
- Windows XP and 2K


Recomended system :
- Windows XP
- P4-3Ghz(Prescott) or AthlonXP2500+ over
- Radeon9600XT or GeForceFX5600 over


#############################################################
Q&A  

Q. The music somtimes interrupted or the performance of demo is bad.

A. At settings dialog, please push [PreRender Music] button.
   Exe starts making wave file.
   And It finished, play demo!! You can get good performance.


#############################################################


Created by System K :
  kioku...code
  sincl...music
  c.r.v...code

Contacts :
  site : http://www.sys-k.net/
  mail : kioku@sys-k.net

This is our 2nd 64k demo;
made with original Real-time software synthesizer, modeler, 
layouter, visual effector, and texture generator.
